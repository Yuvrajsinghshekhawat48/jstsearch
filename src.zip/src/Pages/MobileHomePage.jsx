import React from 'react'

const MobileHomePage = () => {
  return (
    <div>MobileHomePage</div>
  )
}

export default MobileHomePage