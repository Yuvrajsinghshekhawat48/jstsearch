import React from 'react'

const UserPostings = () => {
  return (
    <div className="user-posting">
        
    </div>
  )
}

export default UserPostings