import React from 'react'
import listening from "../../Assests/BDetail_side_Img.svg"
const BuissnessSvg = () => {
  return (
     <div className="listening-svg">
            <img src={listening} alt="Logo" />
        </div>
  )
}

export default BuissnessSvg