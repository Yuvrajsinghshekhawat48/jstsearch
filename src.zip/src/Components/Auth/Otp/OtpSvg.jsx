import React from 'react'
import svg from "../../../Assests/login.png"

const OtpSvg = () => {
  return (
    <div className="login-svg">
        <img src={svg} alt="" />
    </div>
  )
}

export default OtpSvg