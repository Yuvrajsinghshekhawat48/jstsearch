import React from 'react'
import svg from "../../../Assests/login.png"

const LoginSvg = () => {
  return (
    <div className="login-svg">
        <img src={svg} alt="" />
    </div>
  )
}

export default LoginSvg
