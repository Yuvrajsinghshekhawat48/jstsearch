import rest from "../../../Assests/restaurant.png"
import hotel from "../../../Assests/hotel.png"
import spa from "../../../Assests/makeup.png"

export const data = [
    {
        id:1,
        logo:rest,
        name:"Restaurants"
    },
    {
        id:2,
        logo:hotel,
        name:"Hotels"
    },
    {
        id:3,
        logo:spa,
        name:"Beauty Spa"
    },
    {
        id:4,
        logo:rest,
        name:"Restaurants"
    },
    {
        id:5,
        logo:hotel,
        name:"Hotels"
    },
    {
        id:6,
        logo:spa,
        name:"Beauty Spa"
    },
    {
        id:7,
        logo:rest,
        name:"Restaurants"
    },
    {
        id:8,
        logo:hotel,
        name:"Hotels"
    },
    {
        id:9,
        logo:spa,
        name:"Beauty Spa"
    },
    {
        id:10,
        logo:rest,
        name:"Restaurants"
    },
    {
        id:11,
        logo:hotel,
        name:"Hotels"
    },
    {
        id:12,
        logo:spa,
        name:"Beauty Spa"
    },
    {
        id:1,
        logo:rest,
        name:"Restaurants"
    },
    {
        id:2,
        logo:hotel,
        name:"Hotels"
    },
    {
        id:3,
        logo:spa,
        name:"Beauty Spa"
    },
    {
        id:4,
        logo:rest,
        name:"Restaurants"
    },
    {
        id:5,
        logo:hotel,
        name:"Hotels"
    },
    {
        id:6,
        logo:spa,
        name:"Beauty Spa"
    },
    {
        id:7,
        logo:rest,
        name:"Restaurants"
    },
    {
        id:7,
        logo:rest,
        name:"Restaurants"
    },

]