import React from 'react'

const AddFive = () => {
  return (
    <div className="add-five">
        <div className="add-five-box">
            <img src="https://images.unsplash.com/photo-1516882058351-3601a7f420cc?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2lkZSUyMGxhbmRzY2FwZXxlbnwwfHwwfHx8MA%3D%3D" alt="Home Add Image" />
        </div>

        <div className="add-five-box">
            <img src="https://images.unsplash.com/photo-1516882058351-3601a7f420cc?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2lkZSUyMGxhbmRzY2FwZXxlbnwwfHwwfHx8MA%3D%3D" alt="Home Add Image" />
        </div>

        <div className="add-five-box">
            <img src="https://images.unsplash.com/photo-1516882058351-3601a7f420cc?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2lkZSUyMGxhbmRzY2FwZXxlbnwwfHwwfHx8MA%3D%3D" alt="Home Add Image" />
        </div>

        <div className="add-five-box">
            <img src="https://images.unsplash.com/photo-1516882058351-3601a7f420cc?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2lkZSUyMGxhbmRzY2FwZXxlbnwwfHwwfHx8MA%3D%3D" alt="Home Add Image" />
        </div>
    </div>
  )
}

export default AddFive