import React from 'react'

const Navbar = () => {
  return (
    <div className="navbar">
        <h1>Just <span>Search</span></h1>

        <div>
          <p>Home</p>
          <p>Favorite</p>
          <p>Notification</p>
          <p></p>
        </div>
    </div>
  )
}

export default Navbar
